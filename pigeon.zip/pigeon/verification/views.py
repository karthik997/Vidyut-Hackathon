from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from qr_code.qrcode.utils import QRCodeOptions , ContactDetail
from register.models import Register

def myview(request):
    # Build context for rendering QR codes.

    id = Register.objects.values_list('unique_id', flat=True).filter(name='DARSHIK')
    urlid = "http://127.0.0.1:8000/parcel/"+str(list(id)[0])

    contact_detail = ContactDetail(
        first_name='Darshik A S',
        tel='8848052310',
        email='d4rshik@gmail.com',
        url=urlid,
    )

    context = dict(
        contact_detail=contact_detail
    )
    return render(request, 'verification/qr.html', context=context)
