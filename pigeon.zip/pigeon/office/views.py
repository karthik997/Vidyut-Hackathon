from django.shortcuts import render
from register.models import Register

def queue():
    curr_time = Register.objects.values('time')
    for i in curr_time:
        print(i)

# Create your views here.
def home(request,code):
    print(request.method)
    # if request.method == 'GET':
    #     print(code,type(code))
    #     t = Register.objects.get()
    #     if t.unique_id == str(code):
    #         t.status = 'Pending'
    #         t.save()
    #     obj = Register.objects.all()
    #     context = {
    #         'obj':obj,
    #     }
    #     return render(request, 'register/log.html',context)


    obj = Register.objects.all()
    context = {
        'obj':obj,
    }
    return render(request, 'office/parcel.html',context)
