from django.db import models
from django.utils import timezone
from django.utils.crypto import get_random_string

class Register(models.Model):
    parcelid = models.CharField(max_length=10,unique=True)
    name = models.CharField(max_length=100)
    rollno = models.CharField(max_length=16)
    couriertype = models.TextField()
    status = models.CharField(max_length=15,default="Pending")
    time = models.DateTimeField(default=timezone.now)
    unique_id = models.CharField(max_length=32,default=get_random_string(length=32))

    def __str__(self):
        return self.parcelid
