from django.db import models

# Create your models here

class Queue(models.Model):
    slot = models.CharField(max_length=10)
    count = models.IntegerField(default=0)

    def __str__(self):
        return self.slot
