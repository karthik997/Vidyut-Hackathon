from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from  .forms import LoginForm
# Create your views here.

def my_view(request):
    print(request.method)
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            register = form.save(commit=False)
            register.save()
            username = request.POST['username']
            return HttpResponseRedirect('/login')
    else:
        form = LoginForm()
    context = {
        'form':form,
    }
    return render(request, 'user/userreg.html',context)
