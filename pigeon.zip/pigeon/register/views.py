from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from  .forms import RegisterForm
from django.utils import timezone
from django.core.mail import BadHeaderError, send_mail
from .models import Register

def home(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            register = form.save(commit=False)
            register.save()
            obj = Register.objects.all()
            # id = Register.objects.values('parcelid')
            # name = Register.objects.values('name')
            # rollno = Register.objects.values('rollno')
            # couriertype = Register.objects.values('couriertype')
            # arrival = Register.objects.values('time')
            # status = Register.objects.values('status')
            context = {
                'obj':obj,
            }
            return render(request, 'register/log.html',context)
    else:
        form = RegisterForm()
    context = {
        'form':form,
    }
    return render(request, 'register/index.html',context)
