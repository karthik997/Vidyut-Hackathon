from django.shortcuts import render
from django.contrib.auth import authenticate, login

# Create your views here.
def home(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    print(username)
    print(password)
    user = authenticate(request, username=username, password=password)
    if user is not None:
        print(user)
        login(request, user)
    return render(request,'login/log.html')
